//package org.magelan.editor.commands;
//
//import java.awt.Color;
//import java.awt.event.ActionEvent;
//import java.lang.reflect.Method;
//import java.util.List;
//import javax.swing.*;
//
//import org.magelan.core.editor.DefaultDrawingEditor;
//import org.magelan.core.editor.DrawingEditor;
//import org.magelan.editor.commands.EditorCommand;
//
//public class ChangeShapeColor extends EditorCommand {
//    public ChangeShapeColor() {
//        super("ChangeShapeColor");
//        putValue(Action.NAME, "Change Color…");
//        putValue(Action.SHORT_DESCRIPTION, "Change fill/stroke color of selected shape(s)");
//    }
//
//    @Override
//    public void run(DrawingEditor de) {
//        if (!(de instanceof DefaultDrawingEditor)) return;
//        DefaultDrawingEditor ed = (DefaultDrawingEditor)de;
//
//        // grab whatever was selected (could be HexagonEntity, RectangleEntity, etc.)
//        @SuppressWarnings("unchecked")
//        List<Object> sel = ed.getArtist().getSelection();
//        if (sel.isEmpty()) {
//            JOptionPane.showMessageDialog(ed.getContainer(),
//                "Please select one or more shapes first.");
//            return;
//        }
//
//        // Try to get an initial color from the first shape
//        Color initial = Color.BLACK;
//        for (Object o : sel) {
//            try {
//                Method getter = o.getClass().getMethod("getFillColor");
//                Object c = getter.invoke(o);
//                if (c instanceof Color) {
//                    initial = (Color)c;
//                    break;
//                }
//            } catch (Exception ignore) { }
//        }
//
//        // Show chooser
//        Color chosen = JColorChooser.showDialog(
//            ed.getContainer(),
//            "Choose Shape Color",
//            initial
//        );
//        if (chosen == null) return;
//
//        // Apply to all selected shapes
//        for (Object o : sel) {
//            try {
//                Method fillSetter   = o.getClass().getMethod("setFillColor", Color.class);
//                Method strokeSetter = o.getClass().getMethod("setStrokeColor", Color.class);
//                fillSetter.invoke(o, chosen);
//                strokeSetter.invoke(o, chosen);
//            } catch (Exception ignore) { 
//                // if a given object doesn't support these methods, we just skip it
//            }
//        }
//
//        ed.repaint();
//    }
//}
