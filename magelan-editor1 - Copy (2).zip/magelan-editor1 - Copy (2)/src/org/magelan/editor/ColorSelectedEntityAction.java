package org.magelan.editor;


import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.awt.event.ActionEvent;

import org.magelan.core.Entity;
import org.magelan.core.editor.DrawingEditor;
import org.magelan.core.entity.ColorableEntity;
import org.magelan.core.DefaultEntity;


public class ColorSelectedEntityAction extends AbstractAction {

	public ColorSelectedEntityAction() {
		// TODO Auto-generated constructor stub
		super("Change Figure Color");
	}
	
	@Override
    public void actionPerformed(ActionEvent e) {
        DrawingEditor editor = Editor.getEditorManager().getSelectedEditor();
        if (editor == null) return;

        // Get selected entities
        List selection = editor.getSelection();
        if (selection == null || selection.isEmpty()) return;

        // Show color chooser dialog
        Color chosenColor = JColorChooser.showDialog(null, "Choose Color", Color.BLACK);
        if (chosenColor == null) return;

        // Apply color to each selected entity
        for (Object obj : selection) {
            if (obj instanceof Entity) {
                Entity entity = (Entity) obj;
                entity.setColor(chosenColor);
            }
        }

        editor.repaint(); // update display
    }

}
