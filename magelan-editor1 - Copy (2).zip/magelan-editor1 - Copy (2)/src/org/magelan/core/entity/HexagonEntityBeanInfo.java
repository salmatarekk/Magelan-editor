package org.magelan.core.entity;

import java.awt.Color;
import java.beans.*;

public class HexagonEntityBeanInfo extends SimpleBeanInfo {
  private static PropertyDescriptor[] props;

  static {
    try {
      PropertyDescriptor fill = new PropertyDescriptor(
        "fillColor",        // calls getFillColor()/setFillColor()
        HexagonEntity.class
      );
      fill.setDisplayName("Fill Color");

      PropertyDescriptor stroke = new PropertyDescriptor(
        "strokeColor",      // your alias on HexagonEntity
        HexagonEntity.class
      );
      stroke.setDisplayName("Stroke Color");

      props = new PropertyDescriptor[]{ fill, stroke };
    } catch (IntrospectionException ex) {
      props = new PropertyDescriptor[0];
    }
  }

  @Override
  public PropertyDescriptor[] getPropertyDescriptors() {
   // return props;
	  try {
          PropertyDescriptor color = new PropertyDescriptor("color", HexagonEntity.class);
          PropertyDescriptor layer = new PropertyDescriptor("layer", HexagonEntity.class);
          PropertyDescriptor thickness = new PropertyDescriptor("thickness", HexagonEntity.class);
          // Add more descriptors as needed...

          return new PropertyDescriptor[] { color, layer, thickness };
      } catch (IntrospectionException e) {
          e.printStackTrace();
          return null;
      }
  }
  
  
  
 
}
