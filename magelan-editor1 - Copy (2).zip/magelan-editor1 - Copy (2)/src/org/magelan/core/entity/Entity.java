package org.magelan.core.entity;

import java.awt.*;

public interface Entity {
    void draw(Graphics2D g);
    Rectangle getBounds();
}