package org.magelan.core.entity;

public interface ResizableEntity {

		void resize(double factor);
	

}
