package org.magelan.core.entity;

import java.awt.Color;

public interface ColorableEntity {

	
		// TODO Auto-generated constructor stub
		void setColor(Color color);
	    Color getColor();
	

}
