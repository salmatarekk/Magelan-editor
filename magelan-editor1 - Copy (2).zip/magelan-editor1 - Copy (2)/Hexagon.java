package org.magelan.core.entity;

import java.awt.Color;


import java.awt.geom.Rectangle2D;
import org.magelan.drawing.DrawingModel;

import java.awt.Graphics2D;
import java.awt.Shape;

public class HexagonEntity extends PolyLineEntity   {

    public HexagonEntity(Rectangle2D bounds) {
        super();
        setClosed(true);
        setBounds2D(bounds);
    }
    
    
    //Override the paint method to change the hexagon color 
  /*  @Override
    public void paint(Graphics2D g, DrawingModel model) {
        Shape hex = getShape();

        // Set the entity's color
        g.setColor(getColor());

        // Fill the hexagon
        g.fill(hex);

        // Optional: draw border (you can use getLineStyle() or just basic stroke)
        g.setColor(Color.BLACK); // or use getLineStyle().getColor()
        g.draw(hex);
    }
    
    */
    
    @Override
    public void paint(Graphics2D g2d, DrawingModel model) {
    	Shape hexShape = getShape();

        // Fill with the entity's color (setColor is inherited)
        if (getColor() != null) {
            g2d.setColor(getColor());
            g2d.fill(hexShape);
        }

        // Draw the border
        g2d.setColor(Color.BLACK); // or getLineStyle().getColor() if using styles
        g2d.draw(hexShape);
    }
    
    
    /** Alias for the entity’s outline color (core calls it “color”) */
    public Color getStrokeColor() {
        return getColor();      // ← use getColor(), not getLineColor()
    }

    public void setStrokeColor(Color c) {
        setColor(c);            // ← use setColor(...)
    }

    public void setBounds2D(Rectangle2D b) {
        double cx = b.getCenterX(), cy = b.getCenterY();
        double rx = b.getWidth()  / 2.0, ry = b.getHeight() / 2.0;
        double[] xs = new double[6], ys = new double[6];
        for (int i = 0; i < 6; i++) {
            double ang = Math.toRadians(60 * i - 30);
            xs[i] = cx + rx * Math.cos(ang);
            ys[i] = cy + ry * Math.sin(ang);
        }
        setPoints(xs, ys);
    }
    
    
    
    
    
    @Override
    public Shape getShape() {
        // Return a java.awt.Shape representing the hexagon
    	double[] xPoints = getX(); // inherited from PolyLineEntity
        double[] yPoints = getY();

        int nPoints = xPoints.length;
        int[] xInt = new int[nPoints];
        int[] yInt = new int[nPoints];

        for (int i = 0; i < nPoints; i++) {
            xInt[i] = (int) xPoints[i];
            yInt[i] = (int) yPoints[i];
        }

        return new java.awt.Polygon(xInt, yInt, nPoints);
    }

    
    
    
    
}
